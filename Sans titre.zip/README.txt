# Auto SMR — site vitrine

Site statique prêt à publier.

## Fichiers
- `index.html` : page du site
- `style.css` : design rouge/blanc premium

## À modifier avant publication
- Ajouter l'adresse exacte si elle doit apparaître.
- Ajouter l'email si nécessaire.
- Vérifier les services réellement proposés.
- Remplacer les textes génériques par les informations confirmées du garage.
- Ajouter de vraies photos et un logo si le garage les fournit.

## Publication gratuite
Tu peux publier ces fichiers sur un hébergeur statique gratuit qui accepte un dossier contenant `index.html`.
